#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#define MAX_STRING_SIZE 30

typedef struct
{
	char name[MAX_STRING_SIZE];
	char country[MAX_STRING_SIZE];
	int population;
}Cities;


int main(void)
{
	Cities arr[3];
	int i;


	for (i = 0; i < 3; i++)
	{
		printf("Name> ");
		fgets(arr[i].name, MAX_STRING_SIZE, stdin);
		printf("Country> ");
		fgets(arr[i].country, MAX_STRING_SIZE, stdin);
		printf("Population> ");
		scanf("%d", &arr[i].population);

		while (getchar() != '\n');
	} 

	printf("printing the three cities: \n");
	for (i = 0; i < 3; i++)
	{
		arr[i].name[strlen(arr[i].name) - 1] = 0;
		arr[i].country[strlen(arr[i].country) - 1] = 0;
		printf("%d. %s in %s whit a population of %d people \n", i + 1, arr[i].name, arr[i].country, arr[i].population);
	}
	return 0;
}